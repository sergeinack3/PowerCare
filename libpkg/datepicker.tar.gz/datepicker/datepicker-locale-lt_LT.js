Control.DatePicker.Language['lt'] = {
	months: ['Sausis', 'Vasaris', 'Kovas', 'Balandis', 'Gegu&#x017E;&#x0117;', 'Bir&#x017E;elis', 
		'Liepa', 'Rugpj&#x016B;tis', 'Rugs#x0117;jis', 'Spalis', 'Lapkritis', 'Gruodis'],
	days: ['Sek', 'Pir', 'Ant', 'Tre', 'Ket', 'Pen', '&#x0160;e&#x0161;'],
	strings: {
		'Now': 'Dabar',
		'Today': '&#x0160;iandien',
		'Time': 'Laikas',
		'Exact minutes': 'Tikslios minutės',
		'Select Date and Time': 'Pasirink datą ir laiką',
		'Select Time': 'Pasirink laiką',
		'Open calendar': 'Atverti kalendorių'
	}
};

Control.DatePicker.Locale['lt_LT'] = {
	dateTimeFormat: 'yyyy-MM-dd HH:mm',
	dateFormat: 'yyyy-MM-dd',
	timeFormat: 'HH:mm',
	firstWeekDay: 1,
	weekend: [0,6],
	language: 'lt'
};
