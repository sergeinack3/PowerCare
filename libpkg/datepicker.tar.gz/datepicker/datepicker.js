/*
 * Control.DatePicker
 * 2011-05-31
 * 
 * Transforms an ordinary input textbox into an interactive date picker.
 * When the textbox is clicked (or the down arrow is pressed), a calendar
 * appears that the user can browse through and select a date.
 *
 * Features:
 *  - Allows user to specify a date format
 *  - Easy to localize
 *  - Customizable by CSS
 *
 * Written and maintained by Jeremy Jongsma (jeremy@jongsma.org)
 */
if (window.Control == undefined) Control = {};

Control.DatePicker = Class.create();
Control.DatePicker.activePicker = null;
Control.DatePicker.prototype = {
  initialize: function(element, options) {
    this.element = $(element);
    options = options || {};
    this.i18n = new Control.DatePicker.i18n(options.locale || 'en_US');
    options = this.i18n.inheritOptions(options);
    options = Object.extend({
      datePicker: true,
      timePicker: false,
      weekNumber: false,
      icon: null,
      cancelIcon: null,
      dateProperties: [],
      altElement: null,
      altFormat: Control.DatePicker.i18n.baseLocales.iso8601.dateTimeFormat,
      inline: false,
      container: null,
      captureKeys: true,
      emptyButton: false,
      minInterval: 5,
      exactMinutes: true,
      minHours: 0,
      maxHours: 23
    }, options);

    this.handlers = {
      onClick: options.onClick,
      onHover: options.onHover,
      onSelect: options.onSelect 
    };

    this.options = Object.extend(options, {
      onClick: this.pickerClicked.bind(this),
      onHover: this.dateHover.bind(this),
      onSelect: this.datePicked.bind(this)
    });
    
    this.altElement = $(this.options.altElement);
    if (this.altElement) {
      // Synchronize the alt element and the element
      /*this.element.observe('change', function(){
        var date = DateFormat.parseFormat(this.altElement.value, this.options.altFormat);
        this.element.value = DateFormat.format(date, this.options.currentFormat);
      });*/
    }
    
    if (this.options.timePicker && this.options.datePicker)
      this.options.currentFormat = this.options.dateTimeFormat;
    else if (this.options.timePicker)
      this.options.currentFormat = this.options.timeFormat;
    else
      this.options.currentFormat = this.options.dateFormat;
    //this.options.currentFormat = this.options.timePicker ? this.options.dateTimeFormat : this.options.dateFormat;
    //this.options.date = DateFormat.parseFormat(this.element.value, this.options.altFormat);
    if (this.altElement)
      this.options.date = DateFormat.parseFormat(this.altElement.value, this.options.altFormat);
    else
      this.options.date = DateFormat.parseFormat(this.element.value, this.options.currentFormat);

    // Lazy load to avoid excessive CPU usage with lots of controls on one page
    this.datepicker = null;

    this.originalValue = null;
    this.originalAltValue = null;
    this.hideTimeout = null;
    this.icon = null;
    
    if (this.options.icon && !this.options.inline) {
      var cont = new Element('div', {style: 'position:relative;border:none;padding:0;margin:0;display:inline'+(Prototype.Browser.IE&&document.documentMode<8?'':'-block')+';'});
      this.element.wrap(cont);

      // Test if icon is needed
      if (this.options.useIcon) {
        // Create FontAwesome icon
        this.icon = new Element('i', {'class': 'me-icon me-primary inputExtension ' + this.options.icon});
      }
      else {
        this.icon = new Element('img', {src: this.options.icon, title: this.tr('Open calendar')}).addClassName('inputExtension'); // r.2015-01-27
      }

      var padding = this.options.padding;
      if (!padding) {
        // No icon padding specified, default to 3px and calculate dynamically on image load
        padding = 3;
        Event.observe(this.icon, 'load', function() {
          var elementDim = this.element.getDimensions();
          var iconDim = this.icon.getDimensions();
          padding = parseInt(elementDim.height - iconDim.height) / 2;
        }.bind(this));
      }
      Element.setStyle(this.icon, {position: 'absolute', right: padding+'px', top: padding+'px'});
      cont.insert(this.icon);

      Event.observe(this.icon, 'click', this.togglePicker.bindAsEventListener(this));
    } else {
      Event.observe(this.element, 'click', this.togglePicker.bindAsEventListener(this));
    }

    this.hidePickerListener = this.delayedHide.bindAsEventListener(this);
    Event.observe(this.element, 'keydown', this.keyHandler.bindAsEventListener(this));
    Event.observe(document, 'keydown', this.docKeyHandler.bindAsEventListener(this));
    
    if (this.options.inline) this.show();
    this.pickerActive = false;
  },
  tr: function(str) {
    return this.i18n.tr(str);
  },
  save: function() {
    if (!this.originalValue) {
      this.originalValue = this.element.value;
      if (this.altElement) this.originalAltValue = this.altElement.value;
    }
  },
  restore: function() {
    this.element.value = this.originalValue;
    this.originalValue = '';
    if (this.altElement) {
      this.altElement.value = this.originalAltValue;
      this.originalAltValue = '';
    }
  },
  delayedHide: function(e) {
    this.restore();
    this.hideTimeout = setTimeout(this.hide.bind(this), 100);
  },
  pickerClicked: function() {
    if (this.hideTimeout) {
      clearTimeout(this.hideTimeout);
      this.hideTimeout = null;
    }
    if (this.handlers.onClick)
      this.handlers.onClick();
  },
  datePicked: function(date) {
    this.originalAltValue = '';
    this.originalValue = '';
    this.element.value = date ? DateFormat.format(date, this.options.currentFormat) : '';
    if (this.altElement) this.altElement.value = date ? DateFormat.format(date, this.options.altFormat) : '';
    if (!this.element.disabled && this.element.type != 'hidden') this.element.focus();
    this.hide();
    if (this.handlers.onSelect)
      this.handlers.onSelect(date);
    if (this.element.onchange)
      this.element.onchange();
    if (this.altElement && this.altElement.onchange)
      this.altElement.onchange();
  },
  dateHover: function(date) {
    if (this.hideTimeout) {
      clearTimeout(this.hideTimeout);
      this.hideTimeout = null;
    }
    if (this.pickerActive) {
      this.save();
      this.element.value = DateFormat.format(date, this.options.currentFormat);
      if (this.altElement) this.altElement.value = DateFormat.format(date, this.options.altFormat);
      if (this.handlers.onHover)
        this.handlers.onHover(date);
    }
  },
  togglePicker: function(e) {
    if (this.pickerActive) {
      this.restore();
      this.hide();
    } else {
      this.show();
    }
    Event.stop(e);
    return false;
  },
  docKeyHandler: function(e) {
    if (e.keyCode == Event.KEY_ESC && this.pickerActive) {
      this.restore();
      this.hide();
    }
  },
  keyHandler: function(e) {
    switch (e.keyCode) {
      case Event.KEY_ESC:
        this.restore();
      case Event.KEY_TAB:
        this.hide();
        return;
      case Event.KEY_DOWN:  
        if (!this.pickerActive) {
          this.show();
          Event.stop(e);
        }
    }
    if (this.pickerActive)
      return false;
  },
  hide: function() {
    if(this.pickerActive && !this.options.inline) {
      this.datepicker.releaseKeys();
      Element.remove(this.datepicker.element);
      Event.stopObserving(document, 'click', this.hidePickerListener, true);
      this.pickerActive = false;
      Control.DatePicker.activePicker = null;
    }
  },
  show: function () {
    if (!this.pickerActive) {
      if (Control.DatePicker.activePicker)
        Control.DatePicker.activePicker.hide();
      if (!this.element.disabled && this.element.type != 'hidden') this.element.focus();
      if (!this.datepicker)
        this.datepicker = new Control.DatePickerPanel(this.options);
        
      this.save();
     
      if (!this.options.inline) {
        var pos = this.element.cumulativeOffset();
        var dim = this.element.getDimensions();
        this.datepicker.element.setStyle({
          left: pos.left + 'px',
          top: pos.top + dim.height + 'px'
        });
      }
      
      if (this.altElement && this.altElement.value)
        this.datepicker.selectDate(DateFormat.parseFormat(this.altElement.value, this.options.altFormat));
      else
        this.datepicker.selectDate(DateFormat.parseFormat(this.element.value, this.options.currentFormat));

      if (this.options.captureKeys)
        this.datepicker.captureKeys();
        
      var container;
      if (!(container = $(this.options.container))) {
        container = this.options.inline ? this.element : this.element.up();
        container.insert({after: this.datepicker.element});
      }
      else container.insert(this.datepicker.element);
      Event.observe(document, 'click', this.hidePickerListener, true);
      this.pickerActive = true;
      Control.DatePicker.activePicker = this;
      this.pickerClicked();
    }
  }
};

Control.DatePicker.i18n = Class.create();
Object.extend(Control.DatePicker.i18n, {
  baseLocales: {
    'us': {
      dateTimeFormat: 'MM-dd-yyyy HH:mm',
      dateFormat: 'MM-dd-yyyy',
      firstWeekDay: 0,
      weekend: [0,6],
      timeFormat: 'HH:mm'
    },
    'eu': {
      dateTimeFormat: 'dd-MM-yyyy HH:mm',
      dateFormat: 'dd-MM-yyyy',
      firstWeekDay: 1,
      weekend: [0,6],
      timeFormat: 'HH:mm'
    },
    'iso8601': {
      dateTimeFormat: 'yyyy-MM-dd HH:mm',
      dateFormat: 'yyyy-MM-dd',
      firstWeekDay: 1,
      weekend: [0,6],
      timeFormat: 'HH:mm'
    }
  },
  createLocale: function(base, lang) {
    return Object.extend(Object.clone(Control.DatePicker.i18n.baseLocales[base]), {'language': lang});
  }
});
Control.DatePicker.i18n.prototype = {
  initialize: function(code) {
    var lang = code.substring(0,2);
    var locale = (Control.DatePicker.Locale[code] || Control.DatePicker.Locale[lang]);
    this.opts = Object.clone(locale || {});
    var language = locale ? Control.DatePicker.Language[locale.language] : null;
    if (language) Object.extend(this.opts, language);
  },
  opts: null,
  inheritOptions: function(options) {
    if (!this.opts) this.setLocale('en_US');
    return Object.extend(this.opts, options || {});
  },
  tr: function(str) {
    return this.opts && this.opts.strings ? this.opts.strings[str] || str : str;
  }
};

Control.DatePicker.Locale = {};
with (Control.DatePicker) {
  // Full locale definitions not needed if countries use the language default format
  // Datepicker will fallback to the language default; i.e. 'es_AR' will use 'es'
  Locale['es'] = i18n.createLocale('eu', 'es');
  Locale['en'] = i18n.createLocale('us', 'en');
  Locale['en_GB'] = i18n.createLocale('eu', 'en');
  Locale['en_AU'] = Locale['en_GB'];
  Locale['de'] = i18n.createLocale('eu', 'de');
  Locale['es_iso8601'] = i18n.createLocale('iso8601', 'es');
  Locale['en_iso8601'] = i18n.createLocale('iso8601', 'en');
  Locale['de_iso8601'] = i18n.createLocale('iso8601', 'de');
}

Control.DatePicker.Language = {
  'es': {
    months: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Augosto', 'Septiembre', 'Octubre', 'Novimbre', 'Diciembre'],
    days: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa'],
    strings: {
      'Now': 'Ahora',
      'Today': 'Hoy',
      'Time': 'Hora',
      'Exact minutes': 'Minuto exacto',
      'Select Date and Time': 'Selecciona Dia y Hora',
      'Select Time': 'Selecciona Hora',
      'Open calendar': 'Abre calendario'
    }
  },
  'de': { 
    months: ['Januar', 'Februar', 'M&auml;rz', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'], 
    days: ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'], 
    strings: { 
      'Now': 'Jetzt', 
      'Today': 'Heute', 
      'Time': 'Zeit', 
      'Exact minutes': 'Exakte minuten', 
      'Select Date and Time': 'Zeit und Datum Ausw&auml;hlen',
      'Select Time': 'Zeit Ausw&auml;hlen',
      'Open calendar': 'Kalender &ouml;ffnen'
    }
  }  
};

Control.DatePickerPanel = Class.create();
Object.extend(Control.DatePickerPanel.prototype, {
  initialize: function(options) {
    this.i18n = new Control.DatePicker.i18n(options && options.locale ? options.locale : 'en_US');
    options = this.i18n.inheritOptions(options);
    this.options = Object.extend({
            className: 'datepickerControl',
            closeOnToday: true,
            selectToday: true,
            showOnFocus: false,
            datePicker: true,
            timePicker: false,
            use24hrs: false,
            firstWeekDay: 0,
            weekend: [0,6],
            months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
            days: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa']
          }, options || {});
          
    // Make sure first weekday is in the correct range
    with (this.options)
      if (isNaN(firstWeekDay*1)) firstWeekDay = 0;
      else firstWeekDay = firstWeekDay % 7;

    this.keysCaptured = false;
    this.calendarCont = null;
    
    if (this.options.date) {
      this.currentDate = this.options.date;
    }
    else {
      var date = new Date();
      //date.setHours(0);
      date.setMinutes(0);
      date.setSeconds(0);
      this.currentDate = date;
    }
    
    this.dayOfWeek = 0;

    this.selectedDay = null;
    this.selectedHour = null;
    this.selectedMinute = null;
    this.selectedAmPm = null;

    this.currentDays = [];
    this.hourCells = [];
    this.minuteCells = [];
    this.otherMinutes = null;
    this.amCell = null;
    this.pmCell = null;
    this.emptyButton = null;
  
    if (this.options.emptyButton) {
      this.emptyDate = function(){
        this.options.onSelect && this.options.onSelect(null);
      }.bindAsEventListener(this);
      
      this.emptyButton = new Element('button', {type: 'button', className: 'cancel'}).update(this.tr('Empty'));
      this.emptyButton.observe('click', this.emptyDate);
    }

    this.element = this.createPicker();
    this.selectDate(this.currentDate);
  },
  createPicker: function() {
    var elt = new Element('div').setStyle({
      position: this.options.inline ? 'relative' : 'absolute',
      width: 'auto'
    }).addClassName(this.options.className);
    if (this.options.inline) elt.addClassName('inline');
    this.calendarCont = this.drawCalendar(elt, this.currentDate);

    Event.observe(elt, 'click', this.clickHandler.bindAsEventListener(this));
    Event.observe(elt, 'dblclick', this.dblClickHandler.bindAsEventListener(this));
    this.documentKeyListener = this.keyHandler.bindAsEventListener(this);
    if (this.options.captureKeys)
      this.captureKeys();
    
    return elt;
  },
  tr: function(str) {
    return this.i18n.tr(str);
  },
  captureKeys: function() {
    Event.observe(document, 'keydown', this.documentKeyListener, true);
    this.keysCaptured = true;
  },
  releaseKeys: function() {
    Event.stopObserving(document, 'keydown', this.documentKeyListener, true);
    this.keysCaptured = false;
  },
  setDate: function(date) {
    if (date) {
      // Clear container
      this.element.childElements().invoke('remove');
      this.calendarCont = this.drawCalendar(this.element, date);
    }
  },
  drawCalendar: function(container, date) {
    var calCont = container;
    if (!this.options.datePicker) {
      var calTable =  document.createElement('table');
      calTable.cellSpacing = 0;
      calTable.cellPadding = 0;
      calTable.border = 0;
    } else {
      var calTable = this.createCalendar(date);
    }

    var rowwidth = this.options.use24hrs ? 6 : 7;
    if (this.options.timePicker) {
      var timeTable;
      if (this.options.timePickerAdjacent && this.options.datePicker) {
        var rows = 0;

        var adjTable = document.createElement('table');
        adjTable.cellSpacing = 0;
        adjTable.cellPadding = 0;
        adjTable.border = 0;
        
        var row = adjTable.insertRow(0);

        cell = row.insertCell(0);
        cell.vAlign = 'top';
        cell.appendChild(calTable);
        calCont = cell;

        cell = row.insertCell(1);
        cell.style.width = '5px';

        cell = row.insertCell(2);
        cell.vAlign = 'top';
        timeTable = document.createElement('table');
        timeTable.cellSpacing = 0;
        timeTable.cellPadding = 0;
        timeTable.border = 0;
        cell.appendChild(timeTable);

        container.appendChild(adjTable);

        row = timeTable.insertRow(rows++);
        row.className = 'monthLabel';
        cell = row.insertCell(0);
        cell.colSpan = rowwidth;
        cell.innerHTML = this.tr('Time');

        row = timeTable.insertRow(rows++);
        cell = row.insertCell(0);
        cell.colSpan = rowwidth;
        cell.style.height = '1px';

      } else {
        container.appendChild(calTable);
        timeTable = calTable;
        var rows = calTable.rows.length;

        if (this.options.datePicker) {
          row = timeTable.insertRow(rows++);
          cell = row.insertCell(0);
          cell.colSpan = rowwidth;

          var hr = document.createElement('hr');
          Element.setStyle(hr, {color: 'gray', backgroundColor: 'gray', height: '1px', border: '0', marginTop: '3px', marginBottom: '3px', padding: '0'});
          cell.appendChild(hr);
        }
      }

      if (this.options.timePicker && !this.options.datePicker) {
        var today = new Date();
        row = calTable.insertRow(rows++);
        row.className = 'navigation';
        cell = row.insertCell(0);
        cell.colSpan = rowwidth;
        cell.className = 'navbutton now';
        cell.title = today.getHours() + ':' + today.getMinutes();
        cell.innerHTML = this.tr('Now');
        // Date parameter set to NULL in order to get really current date and time since user click
        cell.observe('click', this.dateClickedListener(null, true));
      }

      var hourrows = this.options.use24hrs ? 4 : 2;
      for (var j = 0; j < hourrows; ++j) {
        row = timeTable.insertRow(rows++);
        row.className = 'calendarRow';
        
        for (var i = 0; i < 6; ++i){
          cell = row.insertCell(i);
          cell.className = 'hour';
          cell.width = '14%';
          var hour = (j*6)+i+(this.options.use24hrs?0:1);
          cell.innerHTML = hour;
          if (hour >= this.options.minHours && hour <= this.options.maxHours)
            cell.onclick = this.hourClickedListener(hour);
          else
          cell.className += ' disabled';

          this.hourCells[(j*6)+i] = cell;
        }
        if (!this.options.use24hrs) {
          cell = row.insertCell(i);
          cell.className = 'ampm';
          cell.width = '14%';
          if (j) {
            cell.innerHTML = this.tr('PM');
            cell.onclick = this.pmClickedListener();
            this.pmCell = cell;
          } else {
            cell.innerHTML = this.tr('AM');
            cell.onclick = this.amClickedListener();
            this.amCell = cell;
          }
        }
      }

      row = timeTable.insertRow(rows++);
      cell = row.insertCell(0);
      cell.colSpan = 6;

      var hr = document.createElement('hr');
      Element.setStyle(hr, {color: '#CCCCCC', backgroundColor: '#CCCCCC', height: '1px', border: '0', marginTop: '2px', marginBottom: '2px', padding: '0'});
      cell.appendChild(hr);
      cell = row.insertCell(1);

      for (var j = 0; j < (10/this.options.minInterval); ++j) {
        row = timeTable.insertRow(rows++);
        row.className = 'calendarRow';
        
        for (var i = 0; i < 6; ++i){
          var minval = ((j*6+i)*this.options.minInterval);
          if (minval >= 60) break;
          if (minval < 10) minval = '0'+minval;
          cell = row.insertCell(i);
          cell.className = 'minute';
          cell.width = '14%';
          cell.innerHTML = ':'+minval;
          cell.onclick = this.minuteClickedListener(minval);
          this.minuteCells[(j*6)+i] = cell;
        }
        if (!this.options.use24hrs) {
          cell = row.insertCell(i);
          cell.width = '14%';
        }
      }

      if (this.options.exactMinutes) {
        row = timeTable.insertRow(rows++);
        cell = row.insertCell(0);
        cell.style.textAlign = 'right';
        cell.colSpan = 6;
        cell.className = 'otherminute';
        cell.innerHTML = '<i>'+this.tr('Exact minutes')+': </i>';
        var otherInput = document.createElement('input');
        otherInput.type = 'text';
        otherInput.maxLength = 2;
        otherInput.style.width = '2em';
        var inputTimeout = null;
        
        otherInput.onkeyup = function(e) {
          if (!isNaN(otherInput.value)) {
            this.currentDate.setMinutes(otherInput.value);
            this.dateChanged(this.currentDate);
          }
        }.bindAsEventListener(this);
        
        otherInput.onkeydown = function(e) {
          if (e.keyCode == Event.KEY_RETURN)
            if (this.options.onSelect) this.options.onSelect(this.currentDate);
        }.bindAsEventListener(this);
        
        // Remove event key capture to allow use of arrow keys
        otherInput.onfocus = this.releaseKeys.bindAsEventListener(this);
        otherInput.onblur = this.captureKeys.bindAsEventListener(this);
        
        this.otherMinutes = otherInput;
        cell.appendChild(otherInput);
      }
      
      // Padding cell
      if (!this.options.use24hrs)
        cell = row.insertCell(1);

      row = timeTable.insertRow(rows++);
      cell = row.insertCell(0);
      cell.colSpan = rowwidth;

      hr = document.createElement('hr');
      Element.setStyle(hr, {'color': 'gray', 'backgroundColor': 'gray', 'height': '1px', 'border': '0', 'marginTop': '3px', 'marginBottom': '3px', 'padding': '0'});
      cell.appendChild(hr);

      row = timeTable.insertRow(rows++);
      cell = $(row.insertCell(0));
      cell.colSpan = rowwidth;

      if (this.options.emptyButton)
        cell.insert(this.emptyButton);

      var selectButton = new Element('button', {type: 'button', className: 'tick'});
      
      if (this.options.datePicker)
        selectButton.update(this.tr('Select Date and Time'));
      else
        selectButton.update(this.tr('Select Time'));
        
      selectButton.onclick = function(e) {
        this.options.onSelect && this.options.onSelect(this.currentDate);
      }.bindAsEventListener(this);
      
      cell.insert(selectButton);

    } else {
      calCont.appendChild(calTable);
    }

    return calCont;
  },
  createCalendar: function(date) {
    this.currentDate = date;
    this.currentDays = [];

    var today = new Date();
    var previousYear = new Date(date.getFullYear() - 1, date.getMonth(), 1);
    var previousMonth = new Date(date.getFullYear(), date.getMonth() - 1, 1);
    var nextMonth = new Date(date.getFullYear(), date.getMonth() + 1, 1);
    var nextYear = new Date(date.getFullYear() + 1, date.getMonth(), 1);

    var row;
    var cell;
    var rows = 0;
    var cellOffset = this.options.weekNumber ? 1 : 0;

    var calTable = document.createElement('table');
    calTable.cellSpacing = 0;
    calTable.cellPadding = 0;
    calTable.border = 0;

    row = calTable.insertRow(rows++);
    row.className = 'monthLabel';
    cell = row.insertCell(0);
    cell.colSpan = 7 + cellOffset;
    cell.innerHTML = this.monthName(date.getMonth()) + ' ' + date.getFullYear();

    row = calTable.insertRow(rows++);
    row.className = 'navigation';

    cell = row.insertCell(0);
    cell.className = 'navbutton year previous';
    cell.title = this.monthName(previousYear.getMonth()) + ' ' + previousYear.getFullYear();
    cell.onclick = this.movePreviousYearListener();
    cell.innerHTML = '&lt;&lt;';
    cell.unselectable = 'on'; // for IE
    Event.observe(cell, 'mousedown', this.showSelectorListener());

    cell = row.insertCell(1);
    cell.className = 'navbutton month';
    cell.title = this.monthName(previousMonth.getMonth()) + ' ' + previousMonth.getFullYear();
    cell.onclick = this.movePreviousMonthListener();
    cell.innerHTML = '&lt;';
    cell.unselectable = 'on'; // for IE
    Event.observe(cell, 'mousedown', this.showSelectorListener());

    cell = row.insertCell(2);
    cell.colSpan = 3 + cellOffset;
    cell.className = 'navbutton now';
    cell.title = today.getDate() + ' ' + this.monthName(today.getMonth()) + ' ' + today.getFullYear();
    // Date parameter set to NULL in order to get really current date and time since user click
    cell.observe('click', this.dateClickedListener(null, true));
    if (this.options.timePicker)
      cell.innerHTML = this.tr('Now');
    else
      cell.innerHTML = this.tr('Today');

    cell = row.insertCell(3);
    cell.className = 'navbutton month';
    cell.title = this.monthName(nextMonth.getMonth()) + ' ' + nextMonth.getFullYear();
    cell.onclick = this.moveNextMonthListener();
    cell.innerHTML = '&gt;';
    cell.unselectable = 'on'; // for IE
    Event.observe(cell, 'mousedown', this.showSelectorListener());

    cell = row.insertCell(4);
    cell.className = 'navbutton year next';
    cell.title = this.monthName(nextYear.getMonth()) + ' ' + nextYear.getFullYear();
    cell.onclick = this.moveNextYearListener();
    cell.innerHTML = '&gt;&gt;';
    cell.unselectable = 'on'; // for IE
    Event.observe(cell, 'mousedown', this.showSelectorListener());

    row = calTable.insertRow(rows++);
    row.className = 'dayLabel';

    if (this.options.weekNumber) {
      // Week number column
      cell = row.insertCell(0);
      cell.className = 'weeknumber';
      cell.width = this.options.weekNumber ? '12.5%' : '14%';
    }

    for (var i = 0+cellOffset; i < 7+cellOffset; ++i){
      var dayNumber = (this.options.firstWeekDay + i - cellOffset) % 7;
      cell = $(row.insertCell(i));
      if (dayNumber == 0 || dayNumber == 6) {
        cell.addClassName('weekend');
      }
      cell.width = this.options.weekNumber ? '12.5%' : '14%';
      cell.innerHTML = this.dayName(dayNumber);
    }
    
    row = null;
    var workDate = new Date(date.getFullYear(), date.getMonth(), 1);
    var day = workDate.getDay();
    var j = 0;

    // Pad with previous month
    if (day != this.options.firstWeekDay) {
      row = calTable.insertRow(rows++);
      row.className = 'calendarRow';
      workDate.setDate(workDate.getDate() - ((day - this.options.firstWeekDay + 7) % 7));
      day = workDate.getDay();
      if (this.options.weekNumber) {
        // Week number column
        cell = row.insertCell(0);
        cell.className = 'weeknumber';
        cell.innerHTML = workDate.getWeekNumber();
      }
      while (workDate.getMonth() != date.getMonth()) {
        cell = $(row.insertCell(row.cells.length));
        this.assignDayClasses(cell, 'dayothermonth', workDate);
        cell.innerHTML = workDate.getDate();
        cell.observe('click', this.dateClickedListener(workDate));
        workDate.setDate(workDate.getDate() + 1);
        day = workDate.getDay();
      }
    }

    // Display days
    while (workDate.getMonth() == date.getMonth()) {
      if (day == this.options.firstWeekDay) {
        row = calTable.insertRow(rows++);
        row.className = 'calendarRow';
        if (this.options.weekNumber) {
          // Week number column
          cell = row.insertCell(0);
          cell.className = 'weeknumber';
          cell.innerHTML = workDate.getWeekNumber();
        }
      }

      cell = $(row.insertCell(row.cells.length));
      this.assignDayClasses(cell, 'day', workDate);
      cell.innerHTML = workDate.getDate();
      cell.observe('click', this.dateClickedListener(workDate));
      this.currentDays[workDate.getDate()] = cell;
      workDate.setDate(workDate.getDate() + 1);
      day = workDate.getDay();
    }

    // Pad with next month
    if (day != this.options.firstWeekDay)
      do {
        cell = $(row.insertCell(row.cells.length));
        this.assignDayClasses(cell, 'dayothermonth', workDate);
        cell.innerHTML = workDate.getDate();
        var thisDate = new Date(workDate.getTime());
        cell.observe('click', this.dateClickedListener(workDate));
        workDate.setDate(workDate.getDate() + 1);
        day = workDate.getDay();
      } while (workDate.getDay() != this.options.firstWeekDay);

    if (!this.options.timePicker && this.options.emptyButton) {
      row = calTable.insertRow(rows++);
      cell = $(row.insertCell(0));
      cell.colSpan = 7 + cellOffset;
      cell.insert(this.emptyButton);
    }
    
    return calTable;
  },
  showSelectorListener: function(){
    return function(e){
      e.stop();
      document.observe('mouseup', this.pickInSelectorListener());
      
      var list = new Element('div', {style: 'position:absolute;'}).addClassName('dropdown'),
          element = e.element();
          
      if (element.hasClassName('month')) {
        var currentMonth = this.currentDate.getMonth();
        for(var i = 0; i < 12; i++){
          var item = new Element('a', {href: '#1'}).update(this.monthName(i));
          if (i == currentMonth) item.addClassName('current');
          item.month = i;
          list.insert(item);
        }
      }
      else if (element.hasClassName('year')) {
        var currentYear = parseInt(this.currentDate.getFullYear()),
            asc = element.hasClassName('next');
        for(var i = (asc ? currentYear+1 : currentYear-1); (asc ? i <= currentYear+8 : i >= currentYear-8); (asc ? i++ : i--)){
          var item = new Element('a', {href: '#1'}).update(i);
          item.year = i;
          list.insert(item);
        }
      }
      
      this.dropDownTimeout = setTimeout((function(){
        this.element.insert(list);
        list.clonePosition(element, {setWidth: false, setHeight: false});
        list.style.top = (parseInt(list.style.top) + element.getDimensions().height)+'px';
      }).bind(this), 250);
    }.bindAsEventListener(this);
  },
  pickInSelectorListener: function(){
    return this._pickInSelectorListener || (this._pickInSelectorListener = function(e){
      e.stop();
      var element = e.element();
      if (!Object.isUndefined(element.month)) {
        var month = new Date(
            this.currentDate.getFullYear(),
            element.month,
            this.currentDate.getDate(),
            this.currentDate.getHours(),
            this.currentDate.getMinutes());
        this.selectDate(month);
      }
      else if(element.year) {
        var year = new Date(
            element.year,
            this.currentDate.getMonth(),
            this.currentDate.getDate(),
            this.currentDate.getHours(),
            this.currentDate.getMinutes());
        this.selectDate(year);
      }
      
      this.element.select('div.dropdown').invoke('remove');
      clearTimeout(this.dropDownTimeout);
      document.stopObserving('mouseup', this.pickInSelectorListener());
      
    }.bindAsEventListener(this));
  },
  movePreviousMonthListener: function() {
    return function(e) {
        var prevMonth = new Date(
            this.currentDate.getFullYear(),
            this.currentDate.getMonth() - 1,
            this.currentDate.getDate(),
            this.currentDate.getHours(),
            this.currentDate.getMinutes());
        if (prevMonth.getMonth() != (this.currentDate.getMonth() + 11) % 12) prevMonth.setDate(0);
        this.selectDate(prevMonth);
      }.bindAsEventListener(this);
  },
  moveNextMonthListener: function() {
    return function(e) {
        var nextMonth = new Date(
            this.currentDate.getFullYear(),
            this.currentDate.getMonth() + 1,
            this.currentDate.getDate(),
            this.currentDate.getHours(),
            this.currentDate.getMinutes());
        if (nextMonth.getMonth() != (this.currentDate.getMonth() + 1) % 12) nextMonth.setDate(0);
        this.selectDate(nextMonth);
      }.bindAsEventListener(this);
  },
  moveNextYearListener: function() {
    return function(e) {
        var nextYear = new Date(
            this.currentDate.getFullYear() + 1,
            this.currentDate.getMonth(),
            this.currentDate.getDate(),
            this.currentDate.getHours(),
            this.currentDate.getMinutes());
        if (nextYear.getMonth() != this.currentDate.getMonth()) nextYear.setDate(0);
        this.selectDate(nextYear);
      }.bindAsEventListener(this);
  },
  movePreviousYearListener: function() {
    return function(e) {
        var prevYear = new Date(
            this.currentDate.getFullYear() - 1,
            this.currentDate.getMonth(),
            this.currentDate.getDate(),
            this.currentDate.getHours(),
            this.currentDate.getMinutes());
        if (prevYear.getMonth() != this.currentDate.getMonth()) prevYear.setDate(0);
        this.selectDate(prevYear);
      }.bindAsEventListener(this);
  },
  dateClickedListener: function(date, timeOverride) {
    if (!date) {
      var dateCopy = null;
    }
    else {
      var dateCopy = new Date(date.getTime());
    }
    return function(e) {
        if (e.element().hasClassName('disabled')) 
          return false;
        if (!timeOverride) {
          dateCopy.setHours(this.currentDate.getHours());
          dateCopy.setMinutes(this.currentDate.getMinutes());
          dateCopy.setSeconds(0);
        }
      // Only select date when datePicker or timePicker (no DateTimePicker)
        this.dateClicked(dateCopy, (this.options.timePicker && this.options.datePicker));
      }.bindAsEventListener(this);
  },
  hourClickedListener: function(hour) {
    return function(e) {
        this.hourClicked(hour);
      }.bindAsEventListener(this);
  },
  minuteClickedListener: function(minutes) {
    return function(e) {
        this.currentDate.setMinutes(minutes);
        this.dateClicked(this.currentDate);
      }.bindAsEventListener(this);
  },
  amClickedListener: function() {
    return function(e) {
        if (this.selectedAmPm == this.pmCell) {
          this.currentDate.setHours(this.currentDate.getHours()-12);
          this.dateClicked(this.currentDate);
        }
      }.bindAsEventListener(this);
  },
  pmClickedListener: function() {
    return function(e) {
        if (this.selectedAmPm == this.amCell) {
          this.currentDate.setHours(this.currentDate.getHours()+12);
          this.dateClicked(this.currentDate);
        }
      }.bindAsEventListener(this);
  },
  dateProperties: function(date){
    if (Object.isFunction(this.options.dateProperties))
      return this.options.dateProperties(date);
    else {
      var i, p, range, length = this.options.dateProperties.length, properties = {};
      for(i = 0; i < length; i++) {
        p = this.options.dateProperties[i];
        range = p[0],
        time = date.getTime();
        
        if (Object.isArray(range)) {
          var start = new Date(range[0]).getTime(),
              end = new Date(range[1]).getTime();
              
          if ( range[0] &&  range[1] && time >= start && time <= end || 
               range[0] && !range[1] && time >= start || 
              !range[0] &&  range[1] && time <= end) {
            Object.extend(properties, p[1]);
          }
        }
        else if (time == new Date(range).getTime()) 
          Object.extend(properties, p[1]);
      }
    }
    return properties;
  },
  assignDayClasses: function(cell, baseClass, date) {
    var today = new Date(),
        year = date.getFullYear(),
        month = date.getMonth(),
        day = date.getDate(),
        properties = this.dateProperties(date);

    Element.addClassName(cell, baseClass);
    if (year == today.getFullYear() && month == today.getMonth() && day == today.getDate())
      Element.addClassName(cell, 'today');
    if (this.options.weekend.include(date.getDay()))
      Element.addClassName(cell, 'weekend');
    if (properties.disabled)
      Element.addClassName(cell, 'disabled');
    if (properties.label) {
      Element.addClassName(cell, 'spot');
      cell.writeAttribute('title', properties.label);
    }
    if (properties.className)
      Element.addClassName(cell, properties.className);
  },
  monthName: function(month) {
    return this.options.months[month];
  },
  dayName: function(day) {
    return this.options.days[day];
  },
  dblClickHandler: function(e) {
    var elt = Event.findElement(e, ".calendarRow, .navbutton.now");
    if (elt && this.options.onSelect) {
      this.options.onSelect(this.currentDate);
    }
    Event.stop(e);
  },
  clickHandler: function(e) {
    if(this.options.onClick)
      this.options.onClick();
    Event.stop(e);
  },
  hoverHandler: function(e) {
    if(this.options.onHover)
      this.options.onHover(date);
  },
  keyHandler: function(e) {
    if (!this.options.datePicker && !this.options.timePicker) return false;
    
    // Limited key handling if this is a time picker
    if (!this.options.datePicker) {
      switch (e.keyCode){
        case Event.KEY_DELETE:
        case Event.KEY_BACKSPACE:
          if (this.emptyDate) {
            this.emptyDate();
            break;
          }
      }
    }
    else {
      var days = 0;
      switch (e.keyCode){
        case Event.KEY_RETURN:
          if (this.options.onSelect) this.options.onSelect(this.currentDate);
          break;
        case Event.KEY_LEFT:
          days = -1;
          break;
        case Event.KEY_UP:
          days = -7;
          break;
        case Event.KEY_RIGHT:
          days = 1;
          break;
        case Event.KEY_DOWN:
          days = 7;
          break;
        case Event.KEY_DELETE:
        case Event.KEY_BACKSPACE:
          if (this.emptyDate) {
            this.emptyDate();
            break;
          }
        case 33: // PgUp
          var lastMonth = new Date(this.currentDate.getFullYear(), this.currentDate.getMonth() - 1, this.currentDate.getDate());
          days = -this.getDaysOfMonth(lastMonth);
          break;
        case 34: // PgDn
          days = this.getDaysOfMonth(this.currentDate);
          break;
        case 13: // enter-key (forms without submit buttons)
          this.dateClicked(this.currentDate);
          break;
        default:
          return;
      }
      
      if (days != 0) {
        var moveDate = new Date(this.currentDate.getFullYear(), this.currentDate.getMonth(), this.currentDate.getDate() + days);
        var moveDay = moveDate.getDate();
        if (this.currentDays[moveDay] && this.currentDays[moveDay].hasClassName('disabled'))  // If the target day is disabled
          return e.stop();
        moveDate.setHours(this.currentDate.getHours());
        moveDate.setMinutes(this.currentDate.getMinutes());
        moveDate.setSeconds(0);
        this.selectDate(moveDate);
      }
    }
    Event.stop(e);
    return false;
  },
  getDaysOfMonth: function(date) {
    var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    return lastDay.getDate();
  },
  getNextMonth: function(month, year, increment) {
    if (p_Month == 11) return [0, year + 1];
    else return [month + 1, year];
  },
  getPrevMonth: function(month, year, increment) {
    if (p_Month == 0) return [11, year - 1];
    else return [month - 1, year];
  },
  dateClicked: function(date, isHour) {
    date = date || new Date();
    if (date) {
      if (this.options.onSelect && !isHour)
        this.options.onSelect(date);
      this.selectDate(date);
    }
  },
  dateChanged: function(date) {
    if (date) {
      if ((!this.options.timePicker || !this.options.datePicker) && this.options.onHover)
        this.options.onHover(date);
      this.selectDate(date);
    }
  },
  hourClicked: function(hour) {
    if (!this.options.use24hrs) {
      if (hour == 12 && this.selectedAmPm == this.amCell){
        hour = 0;
      } else if (this.selectedAmPm == this.pmCell) {
        hour += 12;
      }
    }
    this.currentDate.setHours(hour);
    this.dateClicked(this.currentDate, true);
  },
  selectDate: function(date) {
    if (date) {
      if (this.options.datePicker) {
        if (date.getMonth() != this.currentDate.getMonth()
          || date.getFullYear() != this.currentDate.getFullYear())
          this.setDate(date);
        else
          this.currentDate = date;
        
        if (date.getDate() < this.currentDays.length) {
          if (this.selectedDay)
            Element.removeClassName(this.selectedDay, 'current');
          this.selectedDay = this.currentDays[date.getDate()];
          Element.addClassName(this.selectedDay, 'current');
        }
      }

      if (this.options.timePicker) {
        var hours = date.getHours();
        if (this.selectedHour)
          Element.removeClassName(this.selectedHour, 'current');
        if (this.options.use24hrs)
          this.selectedHour = this.hourCells[hours];
        else
          this.selectedHour = this.hourCells[hours % 12 ? (hours % 12) - 1 : 11];
        Element.addClassName(this.selectedHour, 'current');

        if (this.selectedAmPm)
          Element.removeClassName(this.selectedAmPm, 'current');
        this.selectedAmPm = (hours < 12 ? this.amCell : this.pmCell);
        Element.addClassName(this.selectedAmPm, 'current');

        var minutes = date.getMinutes();
        if (this.selectedMinute)
          Element.removeClassName(this.selectedMinute, 'current');
          
        Element.removeClassName(this.otherMinutes, 'current');
        if (minutes % this.options.minInterval == 0) {
          if (this.otherMinutes) {
              this.otherMinutes.clearTimeout = setTimeout(function(){
                this.otherMinutes.value = '';
              }.bind(this), 1000);
          }
          this.selectedMinute = this.minuteCells[minutes / this.options.minInterval];
          Element.addClassName(this.selectedMinute, 'current');
        } else if (this.otherMinutes) {
          clearTimeout(this.otherMinutes.clearTimeout);
          this.otherMinutes.value = minutes;
          Element.addClassName(this.otherMinutes, 'current');
        }
      }

      if (this.options.onHover)
        this.options.onHover(date);
    }
  }
});
