Prism.languages.er7 = {
  'esc': /\\/,
  'fs': /\|/,
  'cs': /\^/,
  'rs': /~/,
  'scs': /&/
};