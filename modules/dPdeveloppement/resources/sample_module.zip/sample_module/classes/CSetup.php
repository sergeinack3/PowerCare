<?php

/**
 * @author  SAS OpenXtrem <dev@openxtrem.com>
{LICENSE}
 */

namespace {NAMESPACE};

use Ox\Core\CSetup;

/**
 * @codeCoverageIgnore
 * {NAME_SHORT} Setup class
 */
class CSetup{PACKAGE} extends CSetup
{
    /**
     * @inheritDoc
     */
    public function __construct()
    {
        parent::__construct();

        $this->mod_name = "{NAME_CANONICAL}";
        $this->makeRevision("0.0");
        $this->makeRevision("0.1");

        $this->setModuleCategory("{MOD_CATEGORY}", "{MOD_PACKAGE}");

        $this->mod_version = "0.2";
    }
}
