<?php

/**
 * @author  SAS OpenXtrem <dev@openxtrem.com>
{LICENSE}
 */

namespace {NAMESPACE};

use Ox\Mediboard\System\AbstractConfigurationRegister;

/**
 * @codeCoverageIgnore
 * {NAME_SHORT}
 */
class CConfiguration{PACKAGE} extends AbstractConfigurationRegister
{
    /**
     * @inheritDoc
     */
    public function register()
    {
    }
}
