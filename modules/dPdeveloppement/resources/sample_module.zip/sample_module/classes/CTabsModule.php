<?php

/**
 * @author  SAS OpenXtrem <dev@openxtrem.com>
{LICENSE}
 */

namespace {NAMESPACE};

use Ox\Core\Module\AbstractTabsRegister;

/**
 * @codeCoverageIgnore
 */
class CTabs{PACKAGE} extends AbstractTabsRegister
{
    public function registerAll(): void
    {
        $this->registerFile('configure', TAB_ADMIN, self::TAB_CONFIGURE);
    }
}
