<?php

/**
 * @author  SAS OpenXtrem <dev@openxtrem.com>
{LICENSE}
 */

namespace {NAMESPACE};

use Ox\Core\CMbObject;
use Ox\Core\CMbObjectSpec;

/**
 * My class
 */
class CMyClass extends CMbObject
{
    /** @var int */
    public $my_class_id;

    /** @var string */
    public $name;

    /**
     * @inheritDoc
     */
    public function getSpec(): CMbObjectSpec
    {
        $spec = parent::getSpec();

        $spec->table = 'my_class';
        $spec->key   = 'my_class_id';

        return $spec;
    }

    /**
     * @inheritDoc
     */
    public function getProps(): array
    {
        $props = parent::getProps();

        $props['name'] = 'str notNull maxLength|50 seekable show|0';

        return $props;
    }

    /**
     * @inheritDoc
     */
    public function updateFormFields(): void
    {
        parent::updateFormFields();

        $this->_view = $this->name;
    }
}
