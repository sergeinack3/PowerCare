-- ------------------------------------------- --
-- Structure des tables composants la base DRC --
-- ------------------------------------------- --

DROP TABLE IF EXISTS `consultation_results`;
CREATE TABLE `consultation_results` (
  `result_id` INT (11) UNSIGNED PRIMARY KEY,
  `title` VARCHAR (255) NOT NULL,
  `nature` ENUM ('1', '3') NOT NULL,
  `sex` ENUM ('1', '2', '3') NOT NULL,
  `episode_type` ENUM ('C', 'A', 'I', 'NC') NOT NULL,
  `version` INT (8) NOT NULL,
  `state` ENUM ('1', '2'),
  `symptom` ENUM ('0', '1'),
  `syndrome` ENUM ('0', '1'),
  `disease` ENUM ('0', '1'),
  `certified_diagnosis` ENUM ('0', '1'),
  `unpathological` ENUM ('0', '1'),
  `details` TEXT,
  `dur_prob_epis` INT (4),
  `age_min` INT (3),
  `age_max` INT (3),
  `cim10_code` VARCHAR (10),
  `cisp_code` VARCHAR (10),
  INDEX (`title`),
  INDEX (`age_min`),
  INDEX (`age_max`),
  INDEX (`state`),
  INDEX (`sex`)
) /*! ENGINE=MyISAM */ COMMENT='Table des r�sultats de consultation';

DROP TABLE IF EXISTS `criteria`;
CREATE TABLE `criteria` (
  `criterion_id` INT (11) UNSIGNED PRIMARY KEY,
  `result_id` INT (11) UNSIGNED,
  `version` INT (4),
  `order` INT (4),
  `title_id` INT (11) UNSIGNED,
  `spacing_id` INT (11) UNSIGNED,
  `ponderation_id` INT (11) UNSIGNED,
  `libelle` VARCHAR (255),
  `parent_id` INT (11) UNSIGNED,
  `validity` ENUM ('0', '1'),
  INDEX (`libelle`),
  INDEX (`result_id`),
  INDEX (`title_id`),
  INDEX (`parent_id`)
) /*! ENGINE=MyISAM */ COMMENT='Table des crit�res associ�s aux r�sultats de consultation';

DROP TABLE IF EXISTS `criteria_titles`;
CREATE TABLE `criteria_titles` (
  `title_id` INT (11) UNSIGNED PRIMARY KEY,
  `title` VARCHAR (255),
  INDEX (`title`)
) /*! ENGINE=MyISAM */ COMMENT='Table des titres des crit�res';

DROP TABLE IF EXISTS `spacings`;
CREATE TABLE `spacings` (
  `spacing_id` INT (11) UNSIGNED PRIMARY KEY,
  `level` VARCHAR (50),
  `text` VARCHAR (50),
  `spaces` INT (2)
) /*! ENGINE=MyISAM */ COMMENT='Table des espacements selon les niveaux de crit�res';

DROP TABLE IF EXISTS `ponderations`;
CREATE TABLE `ponderations` (
  `ponderation_id` INT (11) UNSIGNED PRIMARY KEY,
  `text` VARCHAR (50),
  `comment` VARCHAR (255)
) /*! ENGINE=MyISAM */ COMMENT='Table des pond�ration des crit�res';

DROP TABLE IF EXISTS `result_classes`;
CREATE TABLE `result_classes` (
  `class_id` INT (11) UNSIGNED PRIMARY KEY,
  `text` VARCHAR (255),
  `chapter` VARCHAR (100),
  `libelle` VARCHAR (255),
  `beginning` VARCHAR (50),
  `end` VARCHAR (50)
) /*! ENGINE=MyISAM */ COMMENT='Table des classes de r�sultats de consultation';

DROP TABLE IF EXISTS `results_to_classes`;
CREATE TABLE `results_to_classes` (
  `result_id` INT (11) UNSIGNED,
  `class_id` INT (11) UNSIGNED,
  INDEX (`result_id`),
  INDEX (`class_id`)
) /*! ENGINE=MyISAM */ COMMENT='Table de correspondances des classes et des rc';

DROP TABLE IF EXISTS `critical_diagnoses`;
CREATE TABLE `critical_diagnoses` (
  `diagnosis_id` INT (11) UNSIGNED PRIMARY KEY,
  `libelle` VARCHAR (255),
  `criticality` INT (4),
  `group` INT (1),
  INDEX (`libelle`)
) /*! ENGINE=MyISAM */ COMMENT='Table des diagnostics critiques, vers lesquels peuvent �voluer des rc';

DROP TABLE IF EXISTS `results_to_diagnoses`;
CREATE TABLE `results_to_diagnoses` (
  `result_id` INT (11) UNSIGNED,
  `diagnosis_id` INT (11) UNSIGNED,
  INDEX (`result_id`),
  INDEX (`diagnosis_id`)
) /*! ENGINE=MyISAM */ COMMENT='Table de correspondance des rc vers les diagnostics critiques';

DROP TABLE IF EXISTS `siblings`;
CREATE TABLE `siblings` (
  `result_id` INT (11) UNSIGNED,
  `sibling_id` INT (11) UNSIGNED,
  INDEX (`result_id`),
  INDEX (`sibling_id`)
) /*! ENGINE=MyISAM */ COMMENT='Table des rc voisins';

DROP TABLE IF EXISTS `transcodings`;
CREATE TABLE `transcodings` (
  `transcoding_id` INT (11) UNSIGNED PRIMARY KEY,
  `result_id` INT (11) UNSIGNED,
  `code_cim_1` VARCHAR (10),
  `libelle_cim_1` VARCHAR(255),
  `code_cim_2` VARCHAR (10),
  `libelle_cim_2` VARCHAR(255),
  `code_cisp` VARCHAR (10),
  `libelle_cisp` VARCHAR(255),
  `subtitle` VARCHAR(255),
  INDEX (`result_id`)
) /*! ENGINE=MyISAM */ COMMENT='Table de correspondance des codes CIM10 et CISP vers les RC';

DROP TABLE IF EXISTS `transcoding_criteria`;
CREATE TABLE `transcoding_criteria` (
  `transcoding_criterion_id` INT (11) UNSIGNED PRIMARY KEY,
  `transcoding_id` INT (11) UNSIGNED,
  `criterion_id` INT (11) UNSIGNED,
  `condition` ENUM ('1', '2'),
  INDEX (`transcoding_id`),
  INDEX (`criterion_id`)
) /*! ENGINE=MyISAM */ COMMENT='Table des ';

DROP TABLE IF EXISTS `synonyms`;
CREATE TABLE `synonyms` (
  `synonym_id` INT (11) UNSIGNED PRIMARY KEY,
  `result_id` INT (11) UNSIGNED,
  `libelle` VARCHAR (150),
  INDEX (`libelle`),
  INDEX (`result_id`)
) /*! ENGINE=MyISAM */ COMMENT='Table des synonymes';

DROP TABLE IF EXISTS `versionings`;
CREATE TABLE `versionings` (
  `version_id` INT (11) UNSIGNED PRIMARY KEY,
  `old_result_id` INT (11) UNSIGNED,
  `version` INT (4),
  `result_id` INT (11) UNSIGNED,
  INDEX (`result_id`)
) /*! ENGINE=MyISAM */ COMMENT='Table de correspondance entre RC anciennes versions et version actuelle';