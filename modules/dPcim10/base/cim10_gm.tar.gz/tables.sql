-- ---------------------------------------------------------- --
-- Structure des tables composants la CIM10 GM (version 2016) --
-- ---------------------------------------------------------- --

DROP TABLE IF EXISTS `chapters_gm`;
CREATE TABLE `chapters_gm` (
  `id` INT (11) UNSIGNED PRIMARY KEY,
  `code` VARCHAR (7) NOT NULL,
  `code_long` VARCHAR (9) NOT NULL,
  `parent_id` INT (11) UNSIGNED,
  INDEX (`code`),
  INDEX (`parent_id`)
) /*! ENGINE=MyISAM */ COMMENT='Table des chapitres de la CIM10 GM';

DROP TABLE IF EXISTS `codes_gm`;

CREATE TABLE `codes_gm` (
  `id` INT (11) UNSIGNED PRIMARY KEY,
  `code` VARCHAR (6) NOT NULL,
  `code_long` VARCHAR (8) NOT NULL,
  `chapter_id` INT (11) UNSIGNED NOT NULL,
  `parent_id` INT (11) UNSIGNED,
  `usage` ENUM ('asterisk', 'dagger', 'optional'),
  `sex_code` ENUM ('m', 'w'),
  `sex_reject` ENUM ('9', 'k'),
  `age_low` VARCHAR (4),
  `age_high` VARCHAR (4),
  `age_reject` ENUM ('9', 'k', 'm'),
  `rare_disease` ENUM ('0', '1') DEFAULT '0',
  `content` ENUM ('0', '1') DEFAULT '0',
  `infectious` ENUM ('0', '1') DEFAULT '0',
  `ebm_labour` ENUM ('0', '1') DEFAULT '0',
  `mortality_level1` VARCHAR (5),
  `mortality_level2` VARCHAR (5),
  `mortality_level3` VARCHAR (5),
  `mortality_level4` VARCHAR (5),
  `morbidity` VARCHAR (3),
  `para_295` VARCHAR (1),
  `para_301` VARCHAR (1),
  INDEX (`chapter_id`),
  INDEX (`parent_id`),
  INDEX (`code`),
  INDEX (`usage`)
) /*! ENGINE=MyISAM */ COMMENT='Table des codes de la CIM10 GM';

DROP TABLE IF EXISTS `notes_gm`;

CREATE TABLE `notes_gm` (
  `id` INT (11) UNSIGNED PRIMARY KEY,
  `owner_id` INT (11) UNSIGNED NOT NULL,
  `owner_type` ENUM ('code', 'chapter') NOT NULL,
  `type` ENUM('coding-hint', 'definition', 'exclusion', 'inclusion', 'introduction', 'note', 'preferred', 'preferredLong', 'text') NOT NULL,
  `content` TEXT,
  `parent_id` INT (11) UNSIGNED,
  INDEX (`owner_id`),
  INDEX (`type`),
  INDEX (`parent_id`)
) /*! ENGINE=MyISAM */ COMMENT='Table des notes textuelles de la CIM10 GM';

DROP TABLE IF EXISTS `references_gm`;

CREATE TABLE `references_gm` (
  `id` INT (11) UNSIGNED PRIMARY KEY,
  `note_id` INT (11) UNSIGNED NOT NULL,
  `code_id` INT (11) UNSIGNED NOT NULL,
  `code_type` ENUM ('code', 'chapter') NOT NULL,
  `text` VARCHAR(30),
  `usage` ENUM ('asterisk', 'dagger', 'optional'),
  INDEX (`note_id`),
  INDEX (`code_id`, `code_type`),
  INDEX (`usage`)
) /*! ENGINE=MyISAM */ COMMENT='Table des r�f�rences des notes vers des codes ou chapitres de la CIM10 GM';