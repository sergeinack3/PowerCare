-- ------------------------------------------- --
-- Structure des tables composants la base CISP --
-- ------------------------------------------- --

DROP TABLE IF EXISTS `chapitre`;
CREATE TABLE `chapitre` (
  `lettre` CHAR (1) PRIMARY KEY,
  `description` VARCHAR (64),
  `note` VARCHAR (300)
) /*! ENGINE=MyISAM */ COMMENT='Table des chapitres';

DROP TABLE IF EXISTS `cisp`;
CREATE TABLE `cisp` (
  `code_cisp` CHAR (3) PRIMARY KEY,
  `libelle` VARCHAR (128),
  `codes_cim10` VARCHAR (1024),
  `inclusion` TEXT,
  `exclusion` TEXT,
  `description` TEXT,
  `consideration` TEXT,
  `note` TEXT
) /*! ENGINE=MyISAM */ COMMENT='Table des codes CISP';

DROP TABLE IF EXISTS `procedure`;
CREATE TABLE `procedure` (
  `identifiant` CHAR(3) PRIMARY KEY,
  `description` VARCHAR(100)
) /*! ENGINE=MyISAM */ COMMENT='Table des proc�dures';