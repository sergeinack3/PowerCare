--
-- Base de données: `csarr`
--

-- --------------------------------------------------------

--
-- Structure de la table `activite`
--

DROP TABLE IF EXISTS `activite`;
CREATE TABLE `activite` (
  `hierarchie` varchar(12) NOT NULL,
  `code` char(7) NOT NULL,
  `libelle` varchar(255) NOT NULL,
  `libelle_court` varchar(255) NOT NULL,
  `ordre` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `reference_activite`
--

DROP TABLE IF EXISTS `activite_reference`;
CREATE TABLE `activite_reference` (
  `code` CHAR (7) NOT NULL,
  `libelle` VARCHAR (255) NOT NULL,
  `dedie` ENUM ('oui','non'),
  `non_dedie` ENUM ('possible','non'),
  `collectif` ENUM ('oui'),
  `pluripro` ENUM ('oui'),
  `appareillage` ENUM ('oui'),
  `seance` ENUM ('oui','non')
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `geste_complementaire`
--

DROP TABLE IF EXISTS `geste_complementaire`;
CREATE TABLE `geste_complementaire` (
  `code_source` char(7) NOT NULL,
  `code_cible` char(7) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `hierarchie`
--

DROP TABLE IF EXISTS `hierarchie`;
CREATE TABLE `hierarchie` (
  `code` char(11) NOT NULL,
  `libelle` varchar(255) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `modulateur`
--

DROP TABLE IF EXISTS `modulateur`;
CREATE TABLE `modulateur` (
  `code` char(7) NOT NULL,
  `modulateur` char(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `note_activite`
--

DROP TABLE IF EXISTS `note_activite`;
CREATE TABLE `note_activite` (
  `code` char(7) NOT NULL,
  `idnote` char(10) NOT NULL,
  `typenote` enum('avec_sans','codage','comprend','exclusion','exemple') NOT NULL,
  `niveau` int(11) DEFAULT NULL,
  `libelle` text NOT NULL,
  `ordre` int(11) DEFAULT NULL,
  `code_exclu` char(7) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `note_hierarchie`
--
DROP TABLE IF EXISTS `note_hierarchie`;
CREATE TABLE `note_hierarchie` (
  `hierarchie` char(11) NOT NULL,
  `idnote` char(10) NOT NULL,
  `typenote` enum ('aut_note','avec_sans','codage','compr_tit','def','exclusion','inclus') NOT NULL,
  `niveau` int(11) DEFAULT NULL,
  `libelle` text NOT NULL,
  `ordre` int(11) DEFAULT NULL,
  `hierarchie_exclue` char(11) DEFAULT NULL,
  `code_exclu` char(7) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `code_extension`
--

DROP TABLE IF EXISTS `code_extension`;
CREATE TABLE `code_extension` (
  `code` char(7) NOT NULL,
  `libelle` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
