-- 
-- Base de donn�es: `CdARR`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `intervenant`
-- 

DROP TABLE IF EXISTS `intervenant`;
CREATE TABLE `intervenant` (
  `code` CHAR(2) NOT NULL DEFAULT '',
  `libelle` VARCHAR(50) DEFAULT NULL,
  PRIMARY KEY  (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `type_activite`
-- 

DROP TABLE IF EXISTS `type_activite`;
CREATE TABLE `type_activite` (
  `code` CHAR(2) NOT NULL DEFAULT '',
  `libelle` VARCHAR(50) DEFAULT NULL,
  `libelle_court` VARCHAR(50) DEFAULT NULL,
  PRIMARY KEY  (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Structure de la table `activite`
-- 

DROP TABLE IF EXISTS `activite`;
CREATE TABLE `activite` (
  `code` CHAR(4) NOT NULL DEFAULT '',
  `type` CHAR(2) NOT NULL DEFAULT '',
  `libelle` VARCHAR(250) DEFAULT NULL,
  `note` TEXT DEFAULT NULL,
  `inclu` TEXT DEFAULT NULL,
  `exclu` TEXT DEFAULT NULL,
  PRIMARY KEY  (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
